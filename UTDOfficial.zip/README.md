
*注意事项：

安装使用时需在src/common创建application.js文件（从下面拷一个改名就好）

    H5：使用了有赞ui，参考文档：https://youzan.github.io/vant/#/zh-CN/intro 
 
基于Vue-cli 3.0手脚架搭建，项目本地预览：
    npm install -g serve	// 安装

    serve -s dist		    // 运行 给出的是预览地址
    
CSS热更新问题：vue.config.js修改配置
            css：{ 
                extract：false   // 打包时需改为true，否则打包css问价无法单独抽离出来
            }