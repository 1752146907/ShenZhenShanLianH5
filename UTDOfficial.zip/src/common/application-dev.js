export default {
	host: 'http://localhost:8088',
	codeHost: 'http://localhost:8088',
	imageHost: 'http://localhost:8088',
	appId: '1003604205986484225',
	version: '1.0.0',
	platform: 'Merchant-PC'
};