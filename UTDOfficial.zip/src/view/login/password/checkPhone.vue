<template>
    <div class="login">
        <navBar></navBar>
        <div class="title">UTD</div>
        <div class="from">
            <div class="from-item">
                <div class="from-item-title">手机号码</div>
                <div class="from-item-body">
                    <div class="left">
                        <van-dropdown-menu>
                            <van-dropdown-item active-color="#435FE0" v-model="value1" :options="option1"/>
                        </van-dropdown-menu>
                    </div>
                    <div class="right">
                        <input type="number" placeholder="请输入手机号码"/>
                    </div>
                </div>
            </div>
            <div class="from-item">
                <div class="from-item-title">手机验证码</div>
                <div class="from-item-code">
                    <div class="left">
                        <input type="number" placeholder="请输入手机号码"/>
                    </div>
                    <div class="right">
                        获取验证码
                        <!--                        <span>30S</span>-->
                    </div>
                </div>
            </div>
            <div class="from-submit" @click="handleNext">下一步</div>
            <!--            <div class="from-submit-active">下一步</div> -->
        </div>
    </div>
</template>

<style src="./index.css" scoped></style>

<script>
    import {DropdownMenu, DropdownItem} from 'vant';
    import mixins from '../../../common/mixin';
    import navBar from '../../../component/navBar';

    export default {
        components: {
            DropdownMenu,
            DropdownItem,
            navBar
        },
        mixins: [mixins],
        data: () => ({
            option1: [
                {text: '+86', value: 0},
                {text: '+89', value: 1},
                {text: '+00', value: 2}
            ],
            value1: 0
        }),
        created() {

        },
        methods: {
            handleNext: function () {
                this.$router.push({
                    path: '/forgetPassword',
                    query: {}
                });
            },
        }
    }
</script>
