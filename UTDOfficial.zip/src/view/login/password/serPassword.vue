<template>
    <div class="login">
        <navBar></navBar>
        <div class="title">UTD</div>
        <div class="from">
            <div class="from-item">
                <div class="from-item-title">密码</div>
                <div class="from-item-code">
                    <div class="left">
                        <input type="password" placeholder="请输入密码" />
                    </div>
                </div>
            </div>
            <p class="from-tip">密码必须是8-16位数字加大小写字母。</p>
            <div class="from-item">
                <div class="from-item-title">确认密码</div>
                <div class="from-item-code">
                    <div class="left">
                        <input type="password" placeholder="请确认密码" />
                    </div>
                </div>
            </div>
<!--            <div class="from-submit">重置密码</div>-->
            <div class="from-submit-active">重置密码</div>
        </div>
    </div>
</template>

<style src="./serPassword.css" scoped></style>

<script>
    import { DropdownMenu, DropdownItem } from 'vant';
    import mixins from '../../../common/mixin';
    import navBar from '../../../component/navBar';

    export default {
        components: {
            DropdownMenu,
            DropdownItem,
            navBar
        },
        mixins: [mixins],
        data: () => ({
            option1: [
                { text: '+86', value: 0 },
                { text: '+89', value: 1 },
                { text: '+00', value: 2 }
            ],
            value1: 0
        }),
        created() {

        },
        methods: {
            handleDetail: function () {
                this.$router.push({
                    path: '/my/detail',
                    query: {}
                });
            },
            handleAdd: function () {
                this.$router.push({
                    path: '/archives/add',
                    query: {}
                });
            }
        }
    }
</script>
