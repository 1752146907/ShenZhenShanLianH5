
import Index from './index';
import serPassword from './serPassword';

export default [{
    path: '/login',
    component: Index,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}, {
    path: '/serPassword',
    component: serPassword,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}];