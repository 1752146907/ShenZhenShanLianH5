<template>
	<div class="body">
		<router-view/>
	</div>
</template>

<style src="./main.css" scoped></style>

<script>
    import mixins from '../common/mixin';

    export default {
        components: {

        },
        mixins: [mixins],
        data: () => ({

        }),
        created () {

        },
        mounted () {

        },
        methods: {

        }
    }
</script>
