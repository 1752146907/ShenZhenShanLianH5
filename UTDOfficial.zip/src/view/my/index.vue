<template>
	<div>
		<div class="top">我的</div>
		<div class="handle">
			<img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563773948034&di=4b894493ce37c83f1de4190a02310afe&imgtype=0&src=http%3A%2F%2Fcmsfile03.chinaso.com%2Fgroup1%2FM00%2F0E%2FC2%2FCgqg2FRoYQKAcg52AAku8RIp0xI205.jpg" alt="">
			<div class="handle-right">
				<div class="handle-right-author">13800138000</div>
				<p>创世店主</p>
			</div>
		</div>
		<div class="lable">
			<div class="lable-box">
				<div class="lable-item" @click="handleIntegral">
					<div class="left">
						<img src="./image/menber01.png" alt="">
					</div>
					<div class="right">
						积分划转
					</div>
					<div class="arr">
						<van-icon color="#333333" size="18px" name="arrow" />
					</div>
				</div>
				<div class="lable-item" @click="handleShopkeeper">
					<div class="left">
						<img src="./image/menber02.png" alt="">
					</div>
					<div class="right">
						认购店主
					</div>
					<div class="arr">
						<van-icon color="#333333" size="18px" name="arrow" />
					</div>
				</div>
				<div class="lable-item" @click="handleIdentity">
					<div class="left">
						<img src="./image/menber03.png" alt="">
					</div>
					<div class="right">
						身份认证
					</div>
					<div class="arr">
						<van-icon color="#333333" size="18px" name="arrow" />
					</div>
				</div>
				<div class="lable-item" @click="handleMyPassword">
					<div class="left">
						<img src="./image/menber04.png" alt="">
					</div>
					<div class="right">
						修改密码
					</div>
					<div class="arr">
						<van-icon color="#333333" size="18px" name="arrow" />
					</div>
				</div>
			</div>
		</div>
		<div class="from-submit" @click="handleExit">退出登陆</div>
		<Footer :active="2" />
	</div>
</template>

<style src="./index.css" scoped></style>

<script>
	import mixins from '../../common/mixin';
    import Footer from '../../component/footer/footer';

	export default {
		components: {
            Footer
		},
		mixins: [mixins],
		data: () => ({

		}),
		created () {

		},
		methods: {
			handleExit: function() {
                this.$router.push({
                    path: '/login',
                    query: {}
                });
			},
			handleMyPassword: function() {
				this.$router.push({
					path: '/myPassword',
					query: {}
				});
			},
			handleIdentity: function() {
				this.$router.push({
					path: '/identity',
					query: {}
				});
            },
			handleIntegral: function() {
				this.$router.push({
					path: '/integral',
					query: {}
				});
			},
			handleShopkeeper: function () {
				this.$router.push({
					path: '/shopkeeperIndex',
					query: {}
				});
			}

		}
	}
</script>
