<template>
    <div>
        <navBar title="身份认证"></navBar>
        <div class="title">审核不通过</div>
        <div class="title-text">名字与身份证号码不匹配</div>
        <img class="img" src="./image/error.png" alt="">
        <div class="chack">重新认证</div>
    </div>
</template>

<style src="./error.css" scoped></style>

<script>
    import mixins from '../../../common/mixin';
    import navBar from '../../../component/navBar';

    export default {
        components: {
            navBar
        },
        mixins: [mixins],
        data: () => ({

        }),
        created () {

        },
        methods: {
            handleExit: function() {
                this.$router.push({
                    path: '/login',
                    query: {}
                });
            },
            handleMyPassword: function() {
                this.$router.push({
                    path: '/myPassword',
                    query: {}
                });
            },
            handleSetUp: function() {

            }
        }
    }
</script>
