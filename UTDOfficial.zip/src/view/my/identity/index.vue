<template>
	<div>
		<navBar title="身份认证"></navBar>
		<div class="info">
			<div class="info-item">
				<p>姓名</p>
				<input placeholder="请输入姓名" type="text">
			</div>
			<div class="info-item">
				<p>身份证号</p>
				<input placeholder="请输入身份证号" type="text">
			</div>
			<div class="info-body margin-top-6">
				<img src="./image/identity01.jpg" alt="">
			</div>
			<div class="info-body">
				<img src="./image/identity02.jpg" alt="">
			</div>
			<div class="info-body">
				<img src="./image/identity03.jpg" alt="">
			</div>
			<div class="from-submit" @click="handleSubmit">提交</div>
		</div>
	</div>
</template>

<style src="./index.css" scoped></style>

<script>
	import mixins from '../../../common/mixin';
	import navBar from '../../../component/navBar';

	export default {
		components: {
			navBar
		},
		mixins: [mixins],
		data: () => ({

		}),
		created () {

		},
		methods: {
			handleSubmit: function() {
                this.$router.push({
                    path: '/identityError',
                    query: {}
                });
			},
            handleSetUp: function() {

            }
		}
	}
</script>
