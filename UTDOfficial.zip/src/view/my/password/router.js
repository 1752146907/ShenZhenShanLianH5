
import Index from './index';
import Password from './setPassword';

export default [{
    path: '/myPassword',
    component: Index,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}, {
    path: '/setPassword',
    component: Password,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}];