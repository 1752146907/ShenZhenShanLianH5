<template>
	<div>
		<navBar title="认购店主"></navBar>
		<div class="shopkeeper">
			<div class="subscribe">
				<div class="subscribe-title">家庭店主认购</div>
				<div class="subscribe-children">已售名额</div>
				<van-progress :percentage="80"
							  pivot-text="80"
							  color="#456DE7" />
				<div class="sum">100</div>
			</div>
			<div class="subscribe">
				<div class="subscribe-title">180****8966</div>
				<div class="subscribe-title">
					<b>你已有家庭店主认购资格</b>
					<!--<b>你已是家庭店主</b>-->
				</div>
				<!--<div class="subscribe-opened">
					<p>您的上级 188****7777 是创世店主</p>
					<p style="margin-top: 6px;">请联系他开通家庭店主权益</p>
				</div>-->
			</div>
			<p class="tips"><span>1、</span>认购店主后，立即生效，对在缤纷集绑定了该手机号的账户。</p>
			<p class="tips"><span>2、</span>认购店主后，会解除与上级的绑定关系、停止给上级店主返佣 首单奖励不收影响。</p>
			<p class="tips"><span>3、</span>店主购买后，不可申请取消。</p>
			<p class="tips"><span>4、</span>成为店主后，需遵守缤纷集相关制度，维护缤纷集平台及用户 利益，对于恶意损害缤纷集平台及用户利益者，缤纷集有权关闭 店主权限，且不退换店主购买费用。</p>
			<div class="from-submit" @click="handleSubmit">10,000.00 UTD 立即抢购</div>
		</div>
	</div>
</template>

<style src="./index.css" scoped></style>

<script>
	import mixins from '../../../common/mixin';
	import navBar from '../../../component/navBar';
	import { Dialog } from 'vant';

	export default {
		components: {
			navBar,
			Dialog
		},
		mixins: [mixins],
		data: () => ({

		}),
		created () {

		},
		methods: {
			handleSubmit: function() {
				// 余额充足就正常支付，不足就跳去钱包首页充值
				Dialog.confirm({
					title: '标题',
					message: '弹窗内容',
					confirmButtonColor: '#456DE7'
				}).then(() => {
					// on confirm
				}).catch(() => {
					// on cancel
				});
			},
			handleRecord: function() {
                this.$router.push({
                    path: '/record',
                    query: {}
                });
			}
		}
	}
</script>
