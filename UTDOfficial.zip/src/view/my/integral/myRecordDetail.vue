<template>
    <div>
        <navBar title="划转详情"></navBar>
        <div class="record">
            <div class="price">
                <div class="price-title">划转金额</div>
                <div class="price-body">
                    <div class="price-body-number">+100.00</div>
                    <div class="price-body-type">USTD</div>
                </div>
            </div>
            <div class="record-body">
                <div class="record-item">
                    <div class="record-item-title">类型</div>
                    <div class="record-item-detailed">划转</div>
                </div>
                <div class="record-item">
                    <div class="record-item-title">交易号</div>
                    <div class="record-item-detailed">hcfuidsahuskdnvlksnvuipsdajfioj2w3jdspodfj8oicnfva9wmf9-apmof</div>
                </div>
                <div class="record-item">
                    <div class="record-item-title">划转地址</div>
                    <div class="record-item-detailed">缤纷集到UTD官网</div>
                </div>
                <div class="record-item">
                    <div class="record-item-title">状态</div>
                    <div class="record-item-detailed">已完成</div>
                </div>
                <div class="record-item">
                    <div class="record-item-title">时间</div>
                    <div class="record-item-detailed">2018-09-12 14:38</div>
                </div>
            </div>
        </div>
    </div>
</template>

<style src="./myRecordDetail.css" scoped></style>

<script>
    import mixins from '../../../common/mixin';
    import navBar from '../../../component/navBar';

    export default {
        components: {
            navBar
        },
        mixins: [mixins],
        data: () => ({

        }),
        created () {

        },
        methods: {
            handleRecord: function() {
                this.$router.push({
                    path: '/login',
                    query: {}
                });
            }
        }
    }
</script>
