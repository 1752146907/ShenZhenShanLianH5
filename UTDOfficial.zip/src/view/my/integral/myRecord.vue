<template>
    <div>
        <navBar title="划转记录"></navBar>
        <div class="record">
            <div class="record-item" @click="handleRecordDetail" v-for="index in 4" :key="index">
                <div class="record-title">划转</div>
                <div class="record-item-body">
                    <div class="record-item-body-number">
                        数量
                        <p>+2,994,80</p>
                    </div>
                    <div class="record-item-body-status">
                        状态
                        <p>已完成</p>
                    </div>
                    <div class="record-item-body-time">
                        时间
                        <p>2019/11/04</p>
                        <p>18:14:09</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<style src="./myRecord.css" scoped></style>

<script>
    import mixins from '../../../common/mixin';
    import navBar from '../../../component/navBar';

    export default {
        components: {
            navBar
        },
        mixins: [mixins],
        data: () => ({

        }),
        created () {

        },
        methods: {
            handleRecordDetail: function() {
                this.$router.push({
                    path: '/myRecordDetail',
                    query: {}
                });
            }
        }
    }
</script>
