<template>
	<div>
		<navBar title="积分划转"></navBar>
		<div class="more" @click="handleRecord">划转记录</div>
		<div class="integral">
			<div class="integral-box">
				<div class="integral-box-title">划转</div>
				<div class="from">
					从 <input type="text" placeholder="缤纷集账户" />
				</div>
				<div class="to">
					到 <input type="text" placeholder="UTD官网" />
				</div>
			</div>
			<div class="integral-box">
				<div class="currency-title">币种</div>
				<div class="currency-type">
					UTD
				</div>
				<div class="currency-title">数量</div>
				<div class="number">
					<input type="number" placeholder="请输入划转数量" >
					<span>全部</span>
				</div>
				<div class="available">可用 8888</div>
			</div>
		</div>
		<div class="tisp">缤纷集账户UTD划转到官网钱包后，可用进行交易、提现 等操作,划转不收取手续费。</div>
		<div class="from-submit">划转</div>
	</div>
</template>

<style src="./index.css" scoped></style>

<script>
	import mixins from '../../../common/mixin';
	import navBar from '../../../component/navBar';

	export default {
		components: {
			navBar
		},
		mixins: [mixins],
		data: () => ({

		}),
		created () {

		},
		methods: {
			handleRecord: function() {
                this.$router.push({
                    path: '/myRecord',
                    query: {}
                });
			}
		}
	}
</script>
