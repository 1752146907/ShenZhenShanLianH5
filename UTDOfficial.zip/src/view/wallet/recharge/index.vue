<template>
    <div>
        <navBar title="充币"></navBar>
        <span class="recharge-history" @click="handleHistory">充币记录</span>
        <div class="main">
            <div class="main-body">
                <div class="title">0x83df42AE27Fe1299cC6C00FdffBC9bE2057137A60x83df42AE27Fe1299cC6C00FdffBC9bE2057137A6</div>
                <img class="main-body-code" src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563982147531&di=2425d465d98b2c615b6962b5826ebe18&imgtype=0&src=http%3A%2F%2Fb-ssl.duitang.com%2Fuploads%2Fitem%2F201808%2F12%2F20180812232535_tjfmf.thumb.700_0.jpg" alt="">
                <div class="main-body-footer">
                    复制地址
                </div>
            </div>
            <div class="main-text">
                请勿向上述地址充值任何非ETH资产，否则资产将不可找回。您充值至上述地址后，需要整个网络节点达15个确认后到账，30个确认后可提币。最小充币金额: 0.01 ETH,小于最小金额的充值将不会记录且
                无法退回。目前不支持使用智能合约或区块奖励(Coinbase)的转账充值智能合约或区块奖励的转账将不会入账，请您谅解。您的充值地址不会经常改变，可以重复充值;如有更改，我们
                会尽量通过网站公告或邮件通知您。请务必确认电脑及浏览器安全，防止信息被篡改或泄露。
            </div>
        </div>

    </div>
</template>

<style src="./index.css" scoped></style>

<script>
    import navBar from '../../../component/navBar';
    import mixins from '../../../common/mixin';
    import Footer from '../../../component/footer/footer';

    export default {
        components: {
            Footer,
            navBar
        },
        mixins: [mixins],
        data: () => ({

        }),
        created() {

        },
        methods: {
            handleHistory: function () {
                this.$router.push({
                    path: '/walletRechargeHistory',
                    query: {}
                });
            }
        }
    }
</script>
