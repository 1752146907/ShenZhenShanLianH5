<template>
    <div>
        <navBar title="提币"></navBar>
        <span class="recharge-history" @click="handleHistory">提币记录</span>
        <div class="main">
            <div class="main-body">
                <div class="main-body-address">
                    <div class="main-body-title">提币地址</div>
                    <input type="text" placeholder="输入或长按粘贴地址" class="address-input">
                </div>
            </div>
            <div class="main-body">
                <div class="main-body-address">
                    <div class="main-body-title">提币数量</div>
                    <div class="main-body-number">
                        <input type="number" placeholder="最小提币数量1">
                        UTD<div class="main-body-number-line"></div>全部
                    </div>
                    <div class="main-body-number margin-bottom-15">
                        <span class="day">当日可提100.22UTD</span>
                        <div class="main-body-number-line2"></div>
                        <span class="month">当月可提100,218.22UTD</span>
                    </div>
                    <div class="main-body-title">手续费</div>
                    <div class="main-body-cost">
                        <input type="number" v-model="cost" class="cost-input" />
                        UTD
                    </div>
                    <p class="main-body-tips">最小提币数量为: 1ETH。</p>
                    <p class="main-body-tips">为保障资金安全，我们会对提币进行人工审核，请耐心</p>
                    <p class="main-body-tips">等待工作人员审核结果。</p>
                    <p class="main-body-tips">请务必确认网络环境安全，防止信息被篡改或泄露。</p>
                </div>
            </div>
            <div class="actual">
                <div class="actual-title">到账数量</div>
                <div class="actual-number">522.333ETH</div>
            </div>
            <div class="from-submit">确定</div>
        </div>

    </div>
</template>

<style src="./index.css" scoped></style>

<script>
    import navBar from '../../../component/navBar';
    import mixins from '../../../common/mixin';
    import Footer from '../../../component/footer/footer';

    export default {
        components: {
            Footer,
            navBar
        },
        mixins: [mixins],
        data: () => ({
            cost: 0.8
        }),
        created() {

        },
        methods: {
            handleHistory: function () {
                this.$router.push({
                    path: '/walletExtractHistory',
                    query: {}
                });
            }
        }
    }
</script>
