<template>
    <div class="type">
        <div class="top-bar">
            <div class="top-bar-box">
                <img class="top-bar-back" @click="handleBack" src="../../image/back-02.png" alt="">
                ETC
                <span @click="handleList">财务记录</span>
            </div>
        </div>
        <div class="hander">
            <div class="hander-title">77,888.33</div>
            <div class="hander-rmb">≈ ¥ 800.33</div>
            <div class="hander-body">
                <div class="hander-body-left">
                    可用
                    <p>455.22</p>
                </div>
                <div class="hander-line"></div>
                <div class="hander-body-right">
                    冻结
                    <p>100.22</p>
                </div>
            </div>
        </div>
        <div class="type-body">
            <div class="type-body-item"
                 v-for="index in 10"
                 :key="index">
                <div class="title">充币</div>
                <div class="conter">
                    <div class="conter-number">
                        数量
                        <p>+1,222.33</p>
                    </div>
                    <div class="conter-status">
                        状态
                        <p>待审核</p>
                    </div>
                    <div class="conter-time">
                        时间
                        <p class="margin-top-9">2018/11/22</p>
                        <p>18:36:02</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="type-footer">
            <div class="item" @click="handleWalletRecharge">
                <div class="item-pull">充币</div>
            </div>
            <div class="item">
                    <div class="item-push" @click="handleWalletExtract">提币</div>
            </div>
        </div>
        <div v-if="false" class="no-data">
            <img src="./image/error.png" class="no-data-image-icon" alt="">
            <p class="no-data-text">暂无正在进行的充提记录</p>
        </div>
    </div>
</template>

<style src="./type.css" scoped></style>

<script>
    import mixins from '../../common/mixin';

    export default {
        components: {

        },
        mixins: [mixins],
        data: () => ({

        }),
        created () {

        },
        methods: {
            handleWalletRecharge: function() {
                this.$router.push({
                    path: '/walletRecharge',
                    query: {}
                });
            },
            handleWalletExtract: function() {
                this.$router.push({
                    path: '/walletExtract',
                    query: {}
                });
            },
            handleList: function() {
                this.$router.push({
                    path: '/walletHistory',
                    query: {}
                });
            }
        }
    }
</script>
