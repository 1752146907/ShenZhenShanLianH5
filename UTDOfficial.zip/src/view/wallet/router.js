
import Index from './index';
import Type from './type';
import History from './history';
import WalletDetail from './walletDetail';

export default [{
    path: '/wallet',
    component: Index,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}, {
    path: '/walletType',
    component: Type,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}, {
    path: '/walletDetail',
    component: WalletDetail,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}, {
    path: '/walletHistory',
    component: History,
    meta: {
        requireAuth: false,            // 添加该字段，表示进入这个路由是需要登录的
    }
}];