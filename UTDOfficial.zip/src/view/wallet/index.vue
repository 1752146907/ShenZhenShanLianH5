<template>
    <div>
        <div class="chat">
            <div class="hander">
                <div class="title">钱包余额</div>
                <div class="money">¥755.66</div>
            </div>
            <div class="char-type">货币种类</div>
            <div class="chart-body">
                <div class="chart-body-item" @click="handleType">
                    <img class="icon" src="./image/money03.png" alt="">
                    <p class="title">ETH</p>
                    <div class="number">
                        7,590.00
                        <P>
                            ¥766.22
                        </P>
                    </div>
                </div>
                <div class="chart-body-item" @click="handleType">
                    <img class="icon" src="./image/money02.png" alt="">
                    <p class="title">INE</p>
                    <div class="number">
                        7,590.00
                        <P>
                            ¥766.22
                        </P>
                    </div>
                </div>
                <div class="chart-body-item" @click="handleType">
                    <img class="icon" src="./image/money01.png" alt="">
                    <p class="title">UTD</p>
                    <div class="number">
                        7,590.00
                        <P>
                            ¥766.22
                        </P>
                    </div>
                </div>
            </div>
        </div>

        <Footer :active="1" />
    </div>
</template>

<style src="./index.css" scoped></style>

<script>

    import mixins from '../../common/mixin';
    import Footer from '../../component/footer/footer';

    export default {
        components: {
            'Footer': Footer
        },
        mixins: [mixins],
        data: () => ({

        }),
        created() {

        },
        methods: {
            handleType: function () {
                this.$router.push({
                    path: '/walletType',
                    query: {}
                });
            }
        }
    }
</script>
