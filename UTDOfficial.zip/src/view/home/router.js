import Index from './index';

export default [{
	path: '/home',
	component: Index
}];