<template>
    <div class="main">
        <!--banner-->
        <div class="banner">
            <div class="utd">UTD</div>
            <div class="brief">全球实体数字化经济</div>
            <div class="download">
                <span>白皮书</span>
                <img src="./image/download.png" alt="">
            </div>
        </div>
        <!--公告-->
        <div class="notice">
            <van-icon name="volume-o" color="#696969"/>
            <van-swipe style="height: 37px;flex: 1" :show-indicators="false" :autoplay="5000" :duration="1000" vertical>
                <van-swipe-item v-for="index in 4" :key="index">
                    <p class="van-ellipsis">{{index}}、UTD自治委员会即将成立，欢迎大家踊跃报名</p>
                </van-swipe-item>
            </van-swipe>
        </div>
        <!--生态-->
        <div class="ecology">
            <div class="ecology-title">全球生态</div>
            <div class="ecology-box">
                <div class="ecology-box-item">
                    <img src="./image/ecology01.png" alt="">
                    <div class="title">UTD社区</div>
                </div>
                <div class="ecology-box-item">
                    <img src="./image/ecology02.png" alt="">
                    <div class="title">生态基金会</div>
                </div>
                <div class="ecology-box-item">
                    <img src="./image/ecology03.png" alt="">
                    <div class="title">缤纷集</div>
                </div>
                <div class="ecology-box-item">
                    <img src="./image/ecology04.png" alt="">
                    <div class="title">UTD Plus</div>
                </div>
                <div class="ecology-box-item">
                    <img src="./image/ecology05.png" alt="">
                    <div class="title">孵化器</div>
                </div>
            </div>
        </div>
        <!--社区-->
        <div class="community">
            <div class="title">UTD社区</div>
            <div class="title">是一个高度自治的区块链社区</div>
            <div class="community-body">
                <img class="community-img" src="./image/obj01.png" alt="">
                <div class="community-body-box">
                    <div class="item">
                        <div class="item-title">
                            理事会成员
                            <div class="item-number">9999+个成员</div>
                        </div>
                        <img src="./image/ecology07.png" alt="">
                    </div>
                    <div class="item">
                        <div class="item-title">
                            委员会成员
                            <div class="item-number">568个成员</div>
                        </div>
                        <img src="./image/ecology08.png" alt="">
                    </div>
                    <div class="item">
                        <div class="item-title">
                            锁仓UTD
                            <div class="item-number">3,568,124.98个</div>
                        </div>
                        <img src="./image/ecology09.png" alt="">
                    </div>
                </div>
            </div>
        </div>
        <!--新模式-->
        <div class="new">
            <div class="new-title">
                缤纷集
            </div>
            <div class="new-title">
                消费挖矿链商新模式
            </div>
            <div class="new-body">
                <div class="new-left">
                    <div class="item">
                        <div class="title">用户数量</div>
                        <div class="number">566个</div>
                    </div>
                    <div class="item">
                        <div class="title">今日新增</div>
                        <div class="number">566个</div>
                    </div>
                    <div class="item">
                        <div class="title">总订单量</div>
                        <div class="number">566个</div>
                    </div>
                    <div class="item">
                        <div class="title">今日订单</div>
                        <div class="number">566个</div>
                    </div>
                    <div class="item">
                        <div class="title">总交易额</div>
                        <div class="number">566元</div>
                    </div>
                    <div class="item">
                        <div class="title">今日交易额</div>
                        <div class="number">566元</div>
                    </div>
                </div>
                <img class="new-right" src="./image/obj02.png" alt="">
            </div>
        </div>
        <!--线路-->
        <div class="line">
            <img class="line-good" src="./image/good.png" alt="">
            <div class="line-title">路线图 , 我们未来拓展的每一步</div>
            <div class="line-body">
                <swiper :options="swiperOption">
                    <swiper-slide v-for="index in 9" :key="index">
                        <div class="swiper-slide">
                            <div class="line-body-item">
                                <div class="left">
                                    <img class="left-img" src="./image/arr_item.png" alt="">
                                    <b>{{index}}</b>
                                    <span class="dot"></span>
                                </div>
                                <div class="content">
                                    <div class="content-title">1{{index}}年第4季度</div>
                                    <div class="content-text">用户量大到{{index}}00万</div>
                                </div>
                            </div>
                        </div>
                    </swiper-slide>
                </swiper>
            </div>
        </div>
        <!--伙伴-->
        <div class="partner">
            <div class="partner-title">战略合作伙伴</div>
            <div class="partner-body">
                <div class="partner-body-one">
                    <img src="./image/partner01.png" alt="">
                    <img src="./image/partner02.png" alt="">
                    <img src="./image/partner03.png" alt="">
                </div>
                <div class="partner-body-two">
                    <img src="./image/partner04.png" alt="">
                    <img src="./image/partner05.png" alt="">
                    <img src="./image/partner06.png" alt="">
                    <img src="./image/partner07.png" alt="">
                </div>
            </div>
        </div>
        <Footer :active="0"/>
    </div>
</template>

<style src="./index.css" scoped></style>

<script>

    import mixins from '../../common/mixin';
    import Footer from '../../component/footer/footer';

    import 'swiper/dist/css/swiper.css'
    import { swiper, swiperSlide } from 'vue-awesome-swiper'

    export default {
        components: {
            Footer,
            swiper,
            swiperSlide
        },
        mixins: [mixins],
        data: () => ({
            swiperOption: {
                slidesPerView: 2.3,
                spaceBetween: 0,
                freeMode: true,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true
                }
            }
        }),
        mounted() {

        },
        methods: {

        }
    }
</script>
