<template>
    <div class="bar">
        <div class="bar-box">
            <img class="bar-back" @click="handleBack" src="../image/back.png" alt="">
            {{title}}
        </div>
    </div>
</template>

<style>
    .bar{
        height: 44px;
        position: sticky;
        left: 0px;
        top: 0px;
        right: 0px;
        line-height: 44px;
        text-align: center;
        color: #333333;
        font-size: 20px;
        background: #ffffff;
        z-index: 9999;
    }
    .bar-box{
        height: 44px;
        position: relative;
    }
    .bar-back{
        width: 44px;
        height: 44px;
        position: absolute;
        top: 0px;
        left: 0px;
    }
</style>

<script>

    export default {
        components: {

        },
        props: {
            title: {
                required: false
            }
        },
        data: () => ({

        }),
        created () {

        },
        methods: {
            handleBack: function () {
                this.$router.go(-1);//返回上一层
            }
        }
    }
</script>